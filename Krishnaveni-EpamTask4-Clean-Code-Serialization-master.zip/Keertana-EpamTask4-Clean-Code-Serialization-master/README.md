# Keertana-EpamTask4-Clean-Code-Serialization
Clean Code and Serialization
